export async function onRequestGet({ env }) {
  return Response.json({
    supabaseUrl: env.SUPABASE_URL || '',
    supabaseAnonKey: env.SUPABASE_ANON_KEY || '',
    siteUrl: env.SITE_URL || ''
  }, { headers: { 'Cache-Control': 'public, max-age=300' } });
}
